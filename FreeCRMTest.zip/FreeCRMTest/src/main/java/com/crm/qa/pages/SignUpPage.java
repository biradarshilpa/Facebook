package com.crm.qa.pages;

import com.crm.qa.base.BasePage;

public class SignUpPage extends BasePage {
}
